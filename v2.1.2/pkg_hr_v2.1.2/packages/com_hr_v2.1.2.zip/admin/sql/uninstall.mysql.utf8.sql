DROP TABLE IF EXISTS `#__hr_absenceitem_tag_map`;
DROP TABLE IF EXISTS `#__hr_absence_types` ;
DROP TABLE IF EXISTS `#__hr_absence_rating`;
DROP TABLE IF EXISTS `#__hr_absence_frontpage`;
DROP TABLE IF EXISTS `#__hr_absence`;

DROP TABLE IF EXISTS `#__hr_roster_rating`;
DROP TABLE IF EXISTS `#__hr_roster_frontpage`;
DROP TABLE IF EXISTS `#__hr_roster`;

DROP TABLE IF EXISTS `#__hr_plan_rating`;
DROP TABLE IF EXISTS `#__hr_plan_frontpage`;
DROP TABLE IF EXISTS `#__hr_plan`;

DROP TABLE IF EXISTS `#__hr_title_rating`;
DROP TABLE IF EXISTS `#__hr_title_frontpage`;
DROP TABLE IF EXISTS `#__hr_title`;

DROP TABLE IF EXISTS `#__hr_position_rating`;
DROP TABLE IF EXISTS `#__hr_position_frontpage`;
DROP TABLE IF EXISTS `#__hr_position`;

DROP TABLE IF EXISTS `#__hr_machine_rating`;
DROP TABLE IF EXISTS `#__hr_machine_frontpage`;
DROP TABLE IF EXISTS `#__hr_machine`;

DROP TABLE IF EXISTS `#__hr_employee_absence_rating`;
DROP TABLE IF EXISTS `#__hr_employee_absence_frontpage`;
DROP TABLE IF EXISTS `#__hr_employee_absence`;

DROP TABLE IF EXISTS `#__hr_absence_charge_rating`;
DROP TABLE IF EXISTS `#__hr_absence_charge_frontpage`;
DROP TABLE IF EXISTS `#__hr_absence_charge`;


DROP TABLE IF EXISTS `#__hr_admmgrcat_rating`;
DROP TABLE IF EXISTS `#__hr_admmgrcat_frontpage`;
DROP TABLE IF EXISTS `#__hr_admmgrcat`;

DROP TABLE IF EXISTS `#__hr_employee_roster_rating`;
DROP TABLE IF EXISTS `#__hr_employee_roster_frontpage`;
DROP TABLE IF EXISTS `#__hr_employee_roster`;


DROP TABLE IF EXISTS `#__hr_plan_entitlement_rating`;
DROP TABLE IF EXISTS `#__hr_plan_entitlement_frontpage`;
DROP TABLE IF EXISTS `#__hr_plan_entitlement`;


DROP TABLE IF EXISTS `#__hr_plancat_rating`;
DROP TABLE IF EXISTS `#__hr_plancat_frontpage`;
DROP TABLE IF EXISTS `#__hr_plancat`;

DROP TABLE IF EXISTS `#__hr_admmgrcat_rating`;
DROP TABLE IF EXISTS `#__hr_admmgrcat_frontpage`;
DROP TABLE IF EXISTS `#__hr_admmgrcat`;


DROP TABLE IF EXISTS `#__hr_employee_entitlement_rating`;
DROP TABLE IF EXISTS `#__hr_employee_entitlement_frontpage`;
DROP TABLE IF EXISTS `#__hr_employee_entitlement`;

DROP TABLE IF EXISTS `#__hr_rostercat_rating`;
DROP TABLE IF EXISTS `#__hr_rostercat_frontpage`;
DROP TABLE IF EXISTS `#__hr_rostercat`;

DROP TABLE IF EXISTS `#__hr_roster_pattern_rating`;
DROP TABLE IF EXISTS `#__hr_roster_pattern_frontpage`;
DROP TABLE IF EXISTS `#__hr_roster_pattern`;


DROP TABLE IF EXISTS `#__hr_employee_patternline_rating`;
DROP TABLE IF EXISTS `#__hr_employee_patternline_frontpage`;
DROP TABLE IF EXISTS `#__hr_employee_patternline`;

DROP TABLE IF EXISTS `#__hr_duration_rating`;
DROP TABLE IF EXISTS `#__hr_duration_frontpage`;
DROP TABLE IF EXISTS `#__hr_duration`;


DROP TABLE IF EXISTS `#__hr_employee_roster_rating`;
DROP TABLE IF EXISTS `#__hr_employee_roster_frontpage`;
DROP TABLE IF EXISTS `#__hr_employee_roster`;

DROP TABLE IF EXISTS `#__hr_employee_title_rating`;
DROP TABLE IF EXISTS `#__hr_employee_title_frontpage`;
DROP TABLE IF EXISTS `#__hr_employee_title`;


DROP TABLE IF EXISTS `#__hr_positioncat_rating`;
DROP TABLE IF EXISTS `#__hr_positioncat_frontpage`;
DROP TABLE IF EXISTS `#__hr_positioncat`;

DROP TABLE IF EXISTS `#__hr_employee_position_rating`;
DROP TABLE IF EXISTS `#__hr_employee_position_frontpage`;
DROP TABLE IF EXISTS `#__hr_employee_position`;

DROP TABLE IF EXISTS `#__hr_employee_attendance_rating`;
DROP TABLE IF EXISTS `#__hr_employee_attendance_frontpage`;
DROP TABLE IF EXISTS `#__hr_employee_attendance`;

DROP TABLE IF EXISTS `#__hr_employee_approver_rating`;
DROP TABLE IF EXISTS `#__hr_employee_approver_frontpage`;
DROP TABLE IF EXISTS `#__hr_employee_approver`;

DROP TABLE IF EXISTS `#__hr_machinecat_rating`;
DROP TABLE IF EXISTS `#__hr_machinecat_frontpage`;
DROP TABLE IF EXISTS `#__hr_machinecat`;


DROP TABLE IF EXISTS `#__hr_cpanel_rating`;
DROP TABLE IF EXISTS `#__hr_cpanel_frontpage`;
DROP TABLE IF EXISTS `#__hr_cpanel`;